import numpy as np
from mdptetris_experiments.agents.linear_agent import LinearGame
from gym_mdptetris.envs.tetris import Tetris, TetrisFlat, TetrisHeuristic, MelaxTetris, MelaxTetrisFlat, MelaxTetrisHeuristic
env = TetrisHeuristic()




observation = env.reset()
print("obs", observation)
terminated = False
while not terminated:
    observation, reward, terminated, info = env.step(env.action_space.sample())
    print(observation, reward, terminated, info )
    env.render()

    if terminated :
        observation = env.reset()

env.close()